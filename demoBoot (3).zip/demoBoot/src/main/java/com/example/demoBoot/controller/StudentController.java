package com.example.demoBoot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demoBoot.dao.StudentDao;
import com.example.demoBoot.model.StudentData;

@RestController
public class StudentController {
	@Autowired
	StudentDao studentDao;
	@RequestMapping("/insert")
	public String insertData() {
		StudentData studentData = new StudentData();
		studentData.setId(1);
		studentData.setName("Romeo");
		studentData.setDept("IT");
		studentData.setMarks(40);
		
		StudentData studentData1 = new StudentData();
		studentData1.setId(2);
		studentData1.setName("Juliet");
		studentData1.setDept("MEC");
		studentData1.setMarks(60);
		
		studentDao.insertData(studentData);
		studentDao.insertData(studentData1);
		return "Data added successfully";
	}
	
	@GetMapping("/all")
	public List<StudentData> displayData(){
		List<StudentData> studentList = studentDao.displayAll();
		return studentList;
	}
	//@RequestMapping("/delete/{id}")
	@DeleteMapping("/{id}")
	public String deleteData(@PathVariable ("id") int id) {
		studentDao.deleteRecord(id);
		return "Data deleted successfully";
	}
	
	@PostMapping("/student")
	public <T> ResponseEntity<T> insert(@RequestBody StudentData studentData) {
		/*
		 * StudentData studentData1 = new StudentData(); studentData1.setId(2);
		 * studentData1.setName("Juliet"); studentData1.setDept("MEC");
		 * studentData1.setMarks(60);
		 */
	
	studentDao.insertData(studentData);
	return new ResponseEntity<T>(HttpStatus.CREATED);
	
	}
	/*@RequestMapping("/displayAll")
	public List<StudentData> displayData(){
		List<StudentData> studentList = studentDao.displayAll();
		return studentList;
	}*/
	@PutMapping("/student")
	public void updateData(@RequestBody StudentData studentData) {
		studentDao.insertData(studentData);
	}
}
