package com.example.demoBoot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demoBoot.dao.StudentDao;
import com.example.demoBoot.model.StudentData;

@RestController
public class StudentController {
	@Autowired
	StudentDao studentDao;
	@RequestMapping("/insert")
	public String insertData() {
		StudentData studentData = new StudentData();
		studentData.setId(1);
		studentData.setName("Romeo");
		studentData.setDept("IT");
		studentData.setMarks(40);
		
		StudentData studentData1 = new StudentData();
		studentData1.setId(2);
		studentData1.setName("Juliet");
		studentData1.setDept("MEC");
		studentData1.setMarks(60);
		
		studentDao.insertData(studentData);
		studentDao.insertData(studentData1);
		return "Data added successfully";
	}
	
	@RequestMapping("/delete/{id}")
	public String deleteData(@PathVariable ("id") int id) {
		studentDao.deleteRecord(id);
		return "Data deleted successfully";
	}
	@RequestMapping("/displayAll")
	public List<StudentData> displayData(){
		List<StudentData> studentList = studentDao.displayAll();
		return studentList;
	}
}
